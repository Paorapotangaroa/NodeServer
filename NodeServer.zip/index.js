let express = require("express");
let path = require("path");

const knex = require("knex")({
    client: "pg",
    connection: {
        host: "localhost",
        user: "postgres",
        password: "admin",
        database: "bowlers",
        port: 5432
    }
});

let app = express();
const PORT = 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, "views"));

app.listen(PORT, () => {
    console.log("Your app is up and running and is listening on port " + PORT);
});

app.get("/", (req, res) => {
    // THE FOLLOWING CODE IS COMMENTED OUT BECAUSE MY DATABASE WASN'T RUNNING
    // knex.select().from("students").where("id", 12).then(data => {
    //     let students = data;
    //     res.render("index", { listOfStudents: students });
    // }).catch(err => {
    //     console.log(err);
    // })
    let students = ["Barbara", "Tim", "Jason"]
    res.render("index", { listOfStudents: students });

});

app.get("/showStudentName/:name", (req, res) => {

    // THE FOLLOWING CODE IS COMMENTED OUT BECAUSE MY DATABASE WASN'T RUNNING
    let newStudent = req.params.name;
    let students = ["Barbara", "Tim", "Jason", newStudent]
    res.render("index", { listOfStudents: students });
});